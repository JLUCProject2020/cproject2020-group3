
#include <windows.h>
#include <tchar.h> 
#include <commctrl.h>
#include <windowsx.h>
#include "defs.h"

#include "app_property.h"

const TCHAR   szAppName[] = TEXT(APP_NAME);
const char    version[4]  = APP_VERSION;

