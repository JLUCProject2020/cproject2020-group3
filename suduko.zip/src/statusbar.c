
#include <windows.h>
#include "common.h"
#include "utils.h"
#include "global_symbols.h"

HWND    hwnd_statusbar;
int     statusbar_height;

int    fields_width[] = {220, 350, -1};


int CreateStatusBar()
{
    hwnd_statusbar = CreateWindow(STATUSCLASSNAME, NULL,
        SBARS_SIZEGRIP | WS_CHILD | WS_VISIBLE|WS_BORDER,0,0,0,0, hwnd_frame, NULL, g_hInstance, NULL);
    ShowWindow(hwnd_statusbar,  TRUE);
    statusbar_height = win_height(hwnd_statusbar);
    SendMessage(hwnd_statusbar, SB_SETPARTS, (WPARAM)ARRAY_SIZE(fields_width), (LPARAM)fields_width);
    update_statusbar();
    update_statusbar_time();
}


