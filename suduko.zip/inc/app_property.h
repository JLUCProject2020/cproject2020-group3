

#ifndef __APP_PROPERTY_H_
#define __APP_PROPERTY_H_

#include <tchar.h>

//-begin --->
#define    APP_NAME       "������Ϸ"
#define    APP_VERSION    {'0','0','1',0}

#define    szAuthor    TEXT("���")
#define    szCompany   TEXT("9863254")
#define    szEmail     TEXT("jop254plhdolin@gmail.com")
#define    szContact   TEXT("QQ:279252240")

#define    DOC_FILE_SUFFIX    "sdk"  /* Ӧ�ó����ĵ���׺�� */
//<--- -end




extern const TCHAR     szAppName[];
extern const char      version[];
#define    DOC_FILE_FILTER    "������Ϸ�浵(*."DOC_FILE_SUFFIX")\0*."DOC_FILE_SUFFIX"\0\0"

#endif

