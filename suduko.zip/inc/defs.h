

#ifndef __DEFS_H_
#define __DEFS_H_

#include <stdint.h>

#define    FAIL      (-1)
#define    SUCCESS   (0)

#define    MAX_FILE_PATH_LEN    (1024)

typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;

#endif

