

#ifndef __ENV_H_
#define __ENV_H_

extern int scrn_width;  /* ��Ļ���� */
extern int scrn_height; /* ��Ļ�߶� */

extern int cxChar; /* SYSTEM_FIXED_FONT width */
extern int cyChar; /* SYSTEM_FIXED_FONT height */

void env_init();

#endif

